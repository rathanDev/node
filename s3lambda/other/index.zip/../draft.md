
npm init 

npm i aws-sdk --save
npm i util --save

cd other/
zip -r index.zip ../

unresolved function or method require
In IntelliJ 2018.3.2: go to Settings (Preferences) | Languages & Frameworks | Node.js and NPM and enable Coding assistance for Node.js
