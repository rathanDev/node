npm init

npm i aws-sdk --save
npm i async --save
npm i gm --save
